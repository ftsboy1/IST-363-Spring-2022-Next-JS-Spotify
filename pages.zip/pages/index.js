import Head from 'next/head'
import Link from 'next/link'
import Image from 'next/image'

//customer component 
import Button from '../component/Button'
import TracksByGenre from '../component/TracksByGenre'
import Layout from '../component/Layout'



export default function Home() {
  return (
    <Layout>
      <Head>
        <title>Creaeeete Next App</title>
        <link rel="icon" href="/favicon.ico" />
        <mata name= 'description' content="something cool goes here"></mata>
      </Head>
      
      <Image
        src="/images/profile.png" 
        height={200} 
        width={200} 
        alt="Your Name"
      />
    
      <main>
        <h1 className="title">
          <Link href="/posts/first-post">
            <a>First Post</a>  
          </Link>
        </h1>

        <p className="description">
          Get started by editing <code>pages/index.js</code>
        </p>

        <Button 
        label="Register now" 
        path="/posts/first-post"
        type="primary"
        />

        <Button 
        label="Download"
        type="secondary"
      
        />
    
        <Button 
        label="Login"
        path="/posts/first-post"
        type="primary"
        />

        <TracksByGenre/>

      </main>

      <footer>
        ist 363 spoify
      </footer>

    </Layout>
  )
}
