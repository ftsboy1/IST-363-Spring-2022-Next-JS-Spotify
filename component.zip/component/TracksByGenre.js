import {useState} from 'react'
import Tabs from './Tabs'
import Tracks from './Tracks'

const genres  =["Rock",'Country','Hip-hop','All'];
const tracks = [
	{
		title: "Ramble On",
		artist: "Led Zeppelin",
		genre: "Rock"
	},
	{
		title: "Whole Lotta Love",
		artist: "Led Zeppelin",
		genre: "Rock"
	},
	{
		title: "I Walk the Line",
		artist: "Johnny Cash",
		genre: "Country"
	},
	{
		title: "Jolene",
		artist: "Dolly Parton",
		genre: "Country"
	},
	{
		title: "Where I'm From",
		artist: "Jay-Z",
		genre: "Hip-hop"
	},
	{
		title: "Dead Presidents II",
		artist: "Jay-Z",
		genre: "Hip-hop"
	},
];
function filterTracksByGenre(tracks,activeGenre){
    //1. create a new array 
    let filterTracksByGenre = [];
    //2. loop through old array anmd filter results into new array
   // filterTracksByGenre = tracks.filter((track) => {return track.genre === activeGenre});
    //filterTracksByGenre = tracks.filter(track => track.genre === activeGenre);
    //3. return the new array
    if (activeGenre === "All") {
        filterTracksByGenre = tracks;
    } else{
        filterTracksByGenre = tracks.filter((track) => {return track.genre === activeGenre});
    }
    return filterTracksByGenre;
};


const TracksByGenre = () =>{
    const[activeGenre, setActiveGenre] = useState('Rock');
    return <div> 
        <h2> Top songs by Genre</h2>         
        <Tabs 
        items = {genres} 
        activeItem ={activeGenre}
        clickHandler={setActiveGenre}
        />
        <Tracks items={filterTracksByGenre(tracks, activeGenre)}/>
     </div>
}
export default TracksByGenre;
